DROP TABLE IF EXISTS `#__timesheet_items`;
DROP TABLE IF EXISTS `#__timesheet_categories`;